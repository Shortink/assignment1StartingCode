package shapes;

/**
 * Created on February 19, 2025
 * @author bbteruel
 * @version 1.0
 */

public interface IShapes {
	double calcVolume();
	double calcBaseArea();
}
